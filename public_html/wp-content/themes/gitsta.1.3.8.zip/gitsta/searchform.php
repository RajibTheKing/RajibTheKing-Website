<form role="search" method="get" id="searchform" action="<?php echo home_url('/'); ?>" class="navbar-form navbar-left">
    <div>
        <input type="text" value="" name="s" id="s" placeholder="<?php _e('Search...', 'gitsta'); ?>" class="form-control">
    </div>
</form>