<?php get_header(); ?>

<div class="container">
    <div class="text-center">
        <h2><?php echo get_gitsta_theme_option('error_404_title'); ?></h2>
        <?php echo get_gitsta_theme_option('error_404_content'); ?>
    </div>

<?php get_footer(); ?>